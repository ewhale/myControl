<h1>myControl</h1>
<p>Rewritten Picontrol by jetechteam to be compatible with Python 3.7.3 and RetroPie 4.7.1</p>

Original Project(s) Links
<ul>
  <li>NesPi - https://www.westaby.net/nespi/index.html</li>
  <li>Picontrol - https://github.com/jetekteam/picontrol</li>
</ul>

<h2>WIP</h2>
<ul>
  <li>Remove code related to platforms other than Raspberry Pi</li>
  <li>Review the original button options</li>
  <li>Add webserver</li>
</ul>
